import styled from 'styled-components';
import React, { useEffect, useRef, useState } from "react";
import * as d3 from 'd3'

const GenomeChart= styled.div`
    float: right;
    margin-top: 1%;
    margin-left: 20px;
    width: 1000px;
    height: 500px;
    background: white;
    border-radius: 10px;
`
const margin = { top: 50, right: 30, bottom: 60, left: 60 };
const canvasPad = {top: 50, right: 60, bottom: 120, left: 120 }
const font = 15
const outerWidth = 850;
const outerHeight = 300;
const width = outerWidth - margin.left - margin.right;
const height = (outerHeight - margin.top - margin.bottom)/3;

export default function GenomeArch(props) {
  const data = props.filteredData
  const children = props.children
  const ref = useRef()
  const [selection, setSelection] = useState([0, width]);

  useEffect(() => { //Fetch data stored in indexedDB
    const container = d3.select(ref.current);
    d3.select(ref.current).selectAll("*").remove()
  
    const svgChart = container.append('svg')
        .attr('width', outerWidth)
        .attr('height', outerHeight)
        .attr('class', 'svgPlot')
        .style('position', 'absolute')
        .style('margin-left', margin.left + 'px')
        .append('g')
        .attr('transform', `translate(${margin.left}, ${margin.top})`);
  
    const canvasChart = container.append('canvas')
        .attr('width', width)
        .attr('height', height)
        .style('margin-left', canvasPad.left + 'px')
        .style('margin-top', canvasPad.top + 'px')
        .attr('class', 'canvasPlot');
  
    const context = canvasChart.node().getContext('2d');
  
    const x = d3.scaleLinear().domain([d3.min(data, (d) => d.x), d3.max(data, (d) => d.x)]).range([0, width]);
    const y = d3.scaleLinear().domain([d3.min(data, (d) => d.y), Math.ceil(d3.max(data, (d) => d.y))]).range([height, 0]);
  
    const xAxis = d3.axisBottom(x).ticks(4);
    const yAxis = d3.axisLeft(y).ticks(0);

    const gxAxis = svgChart.append('g')
        .attr('transform', `translate(0, ${height})`)
        .attr("stroke-width", 0)
        .style("font-size", "15px")
        .call(xAxis);
  
    const gyAxis = svgChart.append('g') 
        .attr("stroke-width", 0)
        .style("font-size", "15px")
        .call(yAxis);
  
    chartTitle(svgChart, '', 'Generation')
    draw(d3.zoomIdentity, data, context, x, y, gxAxis, gyAxis, xAxis, yAxis)

    const brush = d3.brushX().extent([[0, 0], [width, height]])
        .on("start brush end", (event) => {
          if(event.selection) {
            const indexSelection = event.selection.map(x.invert);
            setSelection(indexSelection)
          }
    });

    svgChart.append('g')
      .call(brush)
      .call(brush.move, [0, width]);
    },[data])
    
    return (
      <React.Fragment>
        <GenomeChart>
          <div ref={ref}>
          </div>
          {children(selection)}
        </GenomeChart>
      </React.Fragment>
    );
}

function draw(transform, data, context, x, y, gxAxis, gyAxis, xAxis, yAxis) {
  const scaleX = transform.rescaleX(x);
  const scaleY = transform.rescaleY(y);

  gxAxis.call(xAxis.scale(scaleX));
  gyAxis.call(yAxis.scale(scaleY));
  
  const f = scaleX(4)
  const d = scaleX(2)
  const barSize = f-d;

  data.forEach(point => {
    const px = scaleX(point.x);
    const py = scaleY(point.y);
    context.fillStyle = point.color
    context.fillRect(px, py, barSize, 0.5)
  });
}

function chartTitle(svgChart, yLabel, xLabel) {
  svgChart.append('text')
        .attr('x', `-${height / 2+(((yLabel.length)-3)*5)}`) //(25*5 is length of text * 5)
        .attr('dy', -(margin.right+font) + "px")
        .attr('transform', 'rotate(-90)')
        .attr("font-family", "Verdana")
        .text(yLabel);

  svgChart.append('text')
      .attr('x', `${width / 2-(10*5)}`)
      .attr('y', `${height + margin.bottom}`)
      .attr("font-family", "Verdana")
      .text(xLabel);
}