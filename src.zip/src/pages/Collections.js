import React from 'react'

function Collections() {
    return (
        <div>
            <h1 className="title">Collections</h1>
        </div>
    )
}

export default Collections