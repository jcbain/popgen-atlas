import React from 'react'

function Home() {
    return (
        <div>
            <h1 className="title">Home</h1>
        </div>
    )
}

export default Home