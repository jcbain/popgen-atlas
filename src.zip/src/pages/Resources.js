import React from 'react'

function Resources() {
    return (
        <div>
            <h1 className="title">Resources</h1>
        </div>
    )
}

export default Resources